<div class="fi-section rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
    <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
        {{ $questionText }}
    </h3>
</div>