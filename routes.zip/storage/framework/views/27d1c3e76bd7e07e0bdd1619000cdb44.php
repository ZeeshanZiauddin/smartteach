<div <?php echo e($attributes); ?>><?php echo $toHtml($slot); ?></div>
<?php /**PATH D:\projects\haseeb\LMS\vendor\spatie\laravel-markdown\resources\views/markdown.blade.php ENDPATH**/ ?>