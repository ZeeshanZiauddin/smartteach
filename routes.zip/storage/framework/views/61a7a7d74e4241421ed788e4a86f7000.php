<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> <?php echo e(static::$heading); ?> <?php $__env->endSlot(); ?>
         <?php $__env->slot('description', null, []); ?> <?php echo e(static::$description); ?> <?php $__env->endSlot(); ?>

        <style>
            .quiz-container {
                display: grid;
                gap: 16px;
            }

            .quiz-card {
                padding: 16px;
                background: #fff;
                border: 1px solid #e5e5e5;
                border-radius: 12px;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .quiz-card-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 8px;
            }

            .quiz-card-title {
                font-weight: 600;
                font-size: 16px;
                color: #1f2937;
            }

            .quiz-card-course,
            .quiz-card-dates {
                font-size: 12px;
                color: #6b7280;
            }

            .quiz-card-link a {
                color: #FFB900;
                font-weight: 600;
                text-decoration: none;
            }

            .quiz-card-link a:hover {
                text-decoration: underline;
            }

            .no-quizzes {
                text-align: center;
                color: #6b7280;
                font-size: 14px;
            }

            .quiz-results {
                background: #f0fdf4;
                border: 1px solid #d1fae5;
                padding: 12px;
                border-radius: 8px;
                font-size: 13px;
            }
        </style>

        <div class="space-y-16">
            
            <!--[if BLOCK]><![endif]--><?php if($pending->isNotEmpty()): ?>
                <h3 style="margin:10px 0px; color:#6b7280; font-weight: bold;"> Pending Quizzes</h3>
                <div class="quiz-container">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="quiz-card">
                            <div class="quiz-card-header">
                                <div class="quiz-card-title"><?php echo e($quiz['title']); ?></div>
                                <div class="quiz-card-course"><?php echo e($quiz['course']); ?></div>
                            </div>
                            <div class="quiz-card-dates">🕒 <?php echo e($quiz['start_at']); ?> → <?php echo e($quiz['end_at']); ?></div>
                            <div class="quiz-card-link" style="text-align: right;">
                                <a href="<?php echo e(url('admin/take-quiz/' . $quiz['id'])); ?>">Take Quiz</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if($completed->isNotEmpty()): ?>
                <h3 style="margin:10px 0px; color:#6b7280; font-weight: bold;">Completed Quizzes</h3>
                <div class="quiz-container">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="quiz-card">
                            <div class="quiz-card-header">
                                <div class="quiz-card-title"><?php echo e($quiz['title']); ?></div>
                                <div class="quiz-card-course"><?php echo e($quiz['course']); ?></div>
                            </div>
                            <div class="quiz-card-dates">🕒 <?php echo e($quiz['start_at']); ?> → <?php echo e($quiz['end_at']); ?></div>
                            <div class="quiz-results">
                                ✅ Correct Answers: <?php echo e($quiz['correctQuestions'] ?? 0); ?>/<?php echo e($quiz['totalQuestions'] ?? 0); ?><br>
                                🏆 Marks: <?php echo e($quiz['totalMarks'] ?? 0); ?>/<?php echo e($quiz['obtainedmarks'] ?? 0); ?><br>
                                📊 Percentage: <?php echo e($quiz['percentage'] ?? 0); ?>%
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($pending->isEmpty() && $completed->isEmpty()): ?>
                <p class="no-quizzes">You are not enrolled in any quizzes yet.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?><?php /**PATH D:\projects\haseeb\LMS\resources\views/filament/widgets/student-quizzes-widget.blade.php ENDPATH**/ ?>