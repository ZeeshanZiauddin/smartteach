<?php echo value($html); ?>

<?php /**PATH D:\projects\haseeb\LMS\vendor\filament\support\resources\views/anonymous-partial.blade.php ENDPATH**/ ?>