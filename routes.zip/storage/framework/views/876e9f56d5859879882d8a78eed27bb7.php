<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> <?php echo e(static::$heading); ?> <?php $__env->endSlot(); ?>

        <style>
            .course-container {
                display: grid;
                gap: 20px;
                margin-top: 15px;
            }

            .course-card {
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: 16px;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
                transition: transform 0.2s ease;
            }

            .course-card:hover {
                transform: translateY(-2px);
            }

            .course-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 8px;
            }

            .course-title {
                font-size: 1.1rem;
                font-weight: 600;
                color: #222;
            }

            .course-date {
                font-size: 0.85rem;
                color: #6b7280;
            }

            .course-teacher {
                font-size: 0.9rem;
                color: #555;
                margin-bottom: 10px;
            }

            .progress-container {
                width: 100%;
                height: 10px;
                background-color: #e5e7eb;
                border-radius: 5px;
                overflow: hidden;
                margin-top: 6px;
            }

            .progress-bar {
                height: 100%;
                background: linear-gradient(90deg, #ff7300, #FFB900);
                transition: width 0.5s ease;
            }

            .progress-label {
                text-align: right;
                font-size: 0.85rem;
                margin-top: 4px;
                color: #444;
                font-weight: 500;
            }

            /* Responsive */
            @media (max-width: 768px) {
                .course-header {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 4px;
                }
            }
        </style>

        <?php
            $courses = $this->getCourses();
        ?>

        <!--[if BLOCK]><![endif]--><?php if($courses->isEmpty()): ?>
            <p style="text-align:center; color:#777;">You are not enrolled in any courses yet.</p>
        <?php else: ?>
            <div class="course-container">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="course-card">
                        <div class="course-header">
                            <h3 class="course-title"><?php echo e($course['title']); ?></h3>
                            <span class="course-date"><?php echo e($course['from']); ?> → <?php echo e($course['to']); ?></span>
                        </div>

                        <p class="course-teacher">👨‍🏫 <?php echo e($course['teacher']); ?></p>

                        <div class="progress-container">
                            <div class="progress-bar" style="width: <?php echo e($course['progress']); ?>%;"></div>
                        </div>
                        <div class="progress-label"><?php echo e($course['progress']); ?>%</div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?><?php /**PATH D:\projects\haseeb\LMS\resources\views/filament/widgets/student-course-progress-widget.blade.php ENDPATH**/ ?>