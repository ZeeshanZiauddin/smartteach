<?php if (isset($component)) { $__componentOriginald2aa9f7b74553621bdcc3c69267ff328 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald2aa9f7b74553621bdcc3c69267ff328 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\PageComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\PageComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* ✅ Custom dashboard layout overrides */
        .dashboard-wrapper {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .dashboard-top {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }

        .dashboard-main {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }

        /* ✅ Responsive layout for large screens */
        @media (min-width: 1024px) {
            .dashboard-main {
                grid-template-columns: repeat(3, 1fr);
            }

            .dashboard-left {
                grid-column: span 2 / span 2;
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }

            .dashboard-right {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }
        }

        /* Optional: Add smooth widget spacing */
    </style>

    <div class="dashboard-wrapper">
        
        <div class="dashboard-top">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getTopWidgets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <!--[if BLOCK]><![endif]--><?php if($widget::canView()): ?>
                    <div class="filament-widgets">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($widget);

$__html = app('livewire')->mount($__name, $__params, 'lw-2602130084-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="dashboard-main">
            
            <div class="dashboard-left">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getLeftWidgets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!--[if BLOCK]><![endif]--><?php if($widget::canView()): ?>
                        <div class="filament-widgets">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($widget);

$__html = app('livewire')->mount($__name, $__params, 'lw-2602130084-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div class="dashboard-right">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getRightWidgets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!--[if BLOCK]><![endif]--><?php if($widget::canView()): ?>
                        <div class="filament-widgets">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($widget);

$__html = app('livewire')->mount($__name, $__params, 'lw-2602130084-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald2aa9f7b74553621bdcc3c69267ff328)): ?>
<?php $attributes = $__attributesOriginald2aa9f7b74553621bdcc3c69267ff328; ?>
<?php unset($__attributesOriginald2aa9f7b74553621bdcc3c69267ff328); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald2aa9f7b74553621bdcc3c69267ff328)): ?>
<?php $component = $__componentOriginald2aa9f7b74553621bdcc3c69267ff328; ?>
<?php unset($__componentOriginald2aa9f7b74553621bdcc3c69267ff328); ?>
<?php endif; ?><?php /**PATH D:\projects\haseeb\LMS\resources\views/filament/pages/custom-dashboard.blade.php ENDPATH**/ ?>