<?php

namespace App\Filament\Resources\AssignmentSubmissions\Pages;

use App\Filament\Resources\AssignmentSubmissions\AssignmentSubmissionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAssignmentSubmission extends CreateRecord
{
    protected static string $resource = AssignmentSubmissionResource::class;
}
