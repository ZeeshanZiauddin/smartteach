<?php

namespace App\Filament\Resources\Courses\Schemas;

use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class CourseForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('title')
                    ->required(),
                Select::make('user_id')
                    ->relationship(
                        name: 'teacher',
                        titleAttribute: 'name',
                        modifyQueryUsing: fn($query, $record) =>
                        $query->whereHas('roles', fn($q) => $q->where('name', 'teacher')) // only teachers
                            ->whereDoesntHave('course', function ($q) use ($record) {
                                // exclude teachers already assigned to another course
                                if ($record) {
                                    $q->where('id', '!=', $record->id); // allow current record when editing
                                }
                            })
                    )
                    ->required()->searchable()->preload(),
                DatePicker::make('from_date')->native(false),
                DatePicker::make('to_date')->native(false),
                RichEditor::make('description')
                    ->columnSpanFull(),

            ]);
    }
}