<?php

namespace App\Filament\Pages;

use App\Models\Quiz;
use Filament\Actions\Action;
use Filament\Facades\Filament;
use Filament\Pages\Page;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Concerns\InteractsWithTable;
use Illuminate\Database\Eloquent\Builder;
use BackedEnum;
class UpcomingQuizzes extends Page implements HasTable
{
    use InteractsWithTable;

    protected static BackedEnum|string|null $navigationIcon = 'heroicon-o-clock';
    protected string $view = 'filament.pages.upcoming-quizzes';
    protected static ?string $navigationLabel = 'Upcoming Quizzes';
    protected static ?string $title = 'Upcoming Quizzes';
    public static function shouldRegisterNavigation(): bool
    {
        $user = Filament::auth()->user();

        // Only show navigation for users with the 'student' role
        return $user && $user->hasRole('student');
    }

    public function table(Tables\Table $table): Tables\Table
    {
        return $table
            ->query(function (Builder $query) {
                $user = auth()->user();

                // Get enrolled course IDs
                $courseIds = $user->enrolledCourses()->pluck('course_id');

                return Quiz::query()
                    ->whereIn('course_id', $courseIds)
                    ->where('start_at', '>', now())
                    ->orderBy('start_at');
            })
            ->columns([
                TextColumn::make('title')->label('Quiz Title')->searchable()->sortable(),
                TextColumn::make('course.title')->label('Course'),
                TextColumn::make('teacher.name')->label('Teacher'),
                TextColumn::make('start_at')->label('Starts At')->dateTime(),
                TextColumn::make('end_at')->label('Ends At')->dateTime(),
                TextColumn::make('topic')->label('Topics')->formatStateUsing(function ($state) {
                    return is_array($state) ? implode(', ', $state) : $state;
                }),
            ])
            ->actions([
                // Action::make('view')
                //     ->label('View Details')
                //     ->url(fn($record) => route('quiz.view', $record))
                //     ->button()
                //     ->icon('heroicon-o-eye'),
            ]);
    }
}